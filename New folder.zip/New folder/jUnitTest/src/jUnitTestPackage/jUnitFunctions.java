package jUnitTestPackage;

public class jUnitFunctions {
	public int addnumbers(int num_1,int num_2) {
		return num_1+num_2;
		}
	public String addStrings(String st1,String st2) {
		return st1+st2;
	}
}
